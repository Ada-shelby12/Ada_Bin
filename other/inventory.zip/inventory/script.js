document.addEventListener('DOMContentLoaded', () => {
    const navLinks = document.querySelectorAll('nav a');
    const contentSections = document.querySelectorAll('.content-section');
    const addProductForm = document.getElementById('add-product-form');
    const productTableBody = document.querySelector('#product-table tbody');
    const totalProductsCount = document.getElementById('total-products-count');
    const lowStockCount = document.getElementById('low-stock-count');
    const totalValue = document.getElementById('total-value');

    // Simulate a simple in-memory product database
    let products = JSON.parse(localStorage.getItem('products')) || [];

    const LOW_STOCK_THRESHOLD = 10; // Define your low stock threshold

    // --- Utility Function to Show/Hide Sections ---
    function showSection(id) {
        // Remove 'active' class from all sections and nav links
        contentSections.forEach(s => s.classList.remove('active'));
        navLinks.forEach(link => link.classList.remove('active'));

        // Add 'active' class to the target section
        const targetSection = document.getElementById(${id}-view);
        if (targetSection) {
            targetSection.classList.add('active');
        }

        // Add 'active' class to the corresponding nav link
        const targetNavLink = document.getElementById(nav-${id});
        if (targetNavLink) {
            targetNavLink.classList.add('active');
        }

        // Perform specific updates when a section is shown
        if (id === 'dashboard') {
            updateDashboard();
        } else if (id === 'products') {
            renderProductList();
        }
        // No specific action for 'add-product' or 'reports' on display
    }

    // --- Navigation Logic ---
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = e.target.id.replace('nav-', ''); // e.g., 'dashboard', 'products'
            showSection(targetId);
        });
    });

    // --- Product Management Logic ---

    // Function to save products to localStorage
    function saveProducts()