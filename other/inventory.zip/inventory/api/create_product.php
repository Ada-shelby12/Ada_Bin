<?php
include 'db_connect.php';
header('Content-Type: application/json');

$response = ['success' => false, 'message' => 'An error occurred.'];

$name = $_POST['name'] ?? '';
$price = $_POST['price'] ?? 0;
$summary = $_POST['summary'] ?? '';
$image_path = null;

// Handle file upload
if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
    $target_dir = "../uploads/";
    $image_name = time() . '_' . basename($_FILES["image"]["name"]);
    $target_file = $target_dir . $image_name;
    
    // Move the uploaded file to the 'uploads' directory
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        $image_path = "uploads/" . $image_name;
    } else {
        $response['message'] = 'Failed to upload image.';
        echo json_encode($response);
        exit;
    }
}

$stmt = $conn->prepare("INSERT INTO products (name, summary, price, image_path) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssds", $name, $summary, $price, $image_path);

if ($stmt->execute()) {
    $response['success'] = true;
    $response['message'] = 'Product added successfully!';
} else {
    $response['message'] = 'Database error: ' . $stmt->error;
}

$stmt->close();
$conn->close();
echo json_encode($response);
?>