<?php
include 'db_connect.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'];

// Optional: Also delete the image file from the server
$stmt_select = $conn->prepare("SELECT image_path FROM products WHERE id = ?");
$stmt_select->bind_param("i", $id);
$stmt_select->execute();
$stmt_select->bind_result($image_path);
$stmt_select->fetch();
$stmt_select->close();

if ($image_path && file_exists('../' . $image_path)) {
    unlink('../' . $image_path);
}

// Delete the record from the database
$stmt_delete = $conn->prepare("DELETE FROM products WHERE id = ?");
$stmt_delete->bind_param("i", $id);

if ($stmt_delete->execute()) {
    echo json_encode(['success' => true, 'message' => 'Product deleted successfully.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error deleting product: ' . $stmt_delete->error]);
}

$stmt_delete->close();
$conn->close();
?>