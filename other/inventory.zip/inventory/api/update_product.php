<?php
include 'db_connect.php';
header('Content-Type: application/json');

// We are getting data as JSON from the frontend
$data = json_decode(file_get_contents('php://input'), true);

$id = $data['id'];
$name = $data['name'];
$summary = $data['summary'];
$price = $data['price'];

$stmt = $conn->prepare("UPDATE products SET name = ?, summary = ?, price = ? WHERE id = ?");
$stmt->bind_param("ssdi", $name, $summary, $price, $id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Product updated successfully.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error updating product: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>